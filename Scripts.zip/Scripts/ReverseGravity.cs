using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReverseGravity : MonoBehaviour
{
    public PlayerMove player;
    public Player2Move player2;

    private bool hasInteracted1 = false;
    private bool hasInteracted2 = false;

    public Rigidbody2D rb; //������ٵ�2D 

    public void Start()
    {
        rb = GetComponent<Rigidbody2D>(); //������ٵ�2D�� ������ rb�� �޾ƿ���
        rb.isKinematic = true; // �߷�ȿ�� �ȹް�
    }

    void OnTriggerStay2D(Collider2D collision)
    {
        if ((player != null && player.isInteracting && !hasInteracted1))
        {
            DoInteract1();
        }
        if ((player2 != null && player2.isInteracting && !hasInteracted2))
        {
            DoInteract2();
        }

    }

    void DoInteract1()
    {
        player.G = player.G * -1;
        hasInteracted1 = true;
    }

    void DoInteract2()
    {
        player2.G = player2.G * -1;
        hasInteracted2 = true;
    }
}

