using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//�÷��̾�� ���� �� �������� �����ϰ� �ϴ� ������ ��ũ��Ʈ

public class DoubleJumpItem : MonoBehaviour
{
    public PlayerMove player1;
    public Player2Move player2;


    // Start is called before the first frame update
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == ("Player1"))
        {
            player1.anim.SetBool("isJumping", false);
            gameObject.SetActive(false);
        }
        else if (collision.gameObject.name == ("Player2"))
        {
            player2.anim.SetBool("isJumping", false);
            gameObject.SetActive(false);
        }
        
    }

}
