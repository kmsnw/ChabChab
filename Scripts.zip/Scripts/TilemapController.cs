using UnityEngine;

public class TilemapController : MonoBehaviour
{
    public GameObject stairsTilemap; // ��� Tilemap GameObject

    void Awake()
    {
        stairsTilemap.SetActive(false); // ���� �� ����
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") && this.CompareTag("Key"))
        {
            stairsTilemap.SetActive(true);
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") && this.CompareTag("Key"))
        {
            stairsTilemap.SetActive(false);
        }
    } 
} 