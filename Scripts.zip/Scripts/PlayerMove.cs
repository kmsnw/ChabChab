using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMove : MonoBehaviour
{
    public bool isInteracting = false; // ��ȣ�ۿ� ����
    public bool canInteract = false;   // ���� ��ȣ�ۿ� ������ ����
    public string sceneName;
    public TimeDirector Td;

    public Vector2 GetCurrentPosition()
    {
        return transform.position;
    }

    public float maxSpeed;
    public float jumpPower;
    public bool playerFall = false;
    public bool playerDie = false;
    public bool timeOver = false;

    public AudioSource audioSource;
    public AudioClip jumpClip;
    public AudioClip DieClip;

    Rigidbody2D rigid;
    SpriteRenderer spriteRenderer;
    Animator anim;

    void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        // ���� (W Ű)
        if (Input.GetKeyDown(KeyCode.W) && !anim.GetBool("isJumping"))
        {
            rigid.velocity = new Vector2(rigid.velocity.x, 0f); // y�ӵ� �ʱ�ȭ
            rigid.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
            anim.SetBool("isJumping", true);
            audioSource.PlayOneShot(jumpClip);
        }

        // ����
        if (Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.D))
            rigid.velocity = new Vector2(rigid.velocity.normalized.x * 0.5f, rigid.velocity.y);

        // �¿� ��ȯ
        if (Input.GetKeyDown(KeyCode.A)) spriteRenderer.flipX = true;
        else if (Input.GetKeyDown(KeyCode.D)) spriteRenderer.flipX = false;

        if (Input.GetKeyDown(KeyCode.S))
        {
            if (canInteract) // ������Ʈ�� �پ� ���� ���� true
                isInteracting = true;
        }
        

        // �ȱ� �ִϸ��̼�
        anim.SetBool("isWalking", rigid.velocity.x != 0);

        if (playerDie || timeOver)
        {
            rigid.velocity = Vector2.zero;
            StartCoroutine(PauseAndResume(2f));
        }

        if (timeOver)
        {
            timeOver = false;
            audioSource.PlayOneShot(DieClip);
        }
    }

    IEnumerator PauseAndResume(float pauseDuration)
    {
        Time.timeScale = 0;
        yield return new WaitForSecondsRealtime(pauseDuration);
        Time.timeScale = 1;
        loadScene();
    }

    void FixedUpdate()
    {
        float h = 0;

        // �̵� A/D
        if (Input.GetKey(KeyCode.A)) h = -1;
        else if (Input.GetKey(KeyCode.D)) h = 1;

        rigid.AddForce(Vector2.right * h, ForceMode2D.Impulse);

        if (rigid.velocity.x > maxSpeed) rigid.velocity = new Vector2(maxSpeed, rigid.velocity.y);
        else if (rigid.velocity.x < -maxSpeed) rigid.velocity = new Vector2(-maxSpeed, rigid.velocity.y);

        // ���� �� �÷��̾� ��� ����
        if (rigid.velocity.y <= 0)
        {
            Vector2 rayOrigin = (Vector2)rigid.position + Vector2.down * 0.5f; // �߽ɺ��� ��¦ �Ʒ�
            RaycastHit2D rayHit = Physics2D.Raycast(
                rayOrigin,
                Vector2.down,
                0.6f, 
                LayerMask.GetMask("Platform","Player")
            );

            if (rayHit.collider != null && rayHit.collider != GetComponent<Collider2D>() && rayHit.distance < 0.5f)
                anim.SetBool("isJumping", false);
        }

        // �� ����
        bool isTouchingWallRight = Physics2D.Raycast(rigid.position, Vector2.right, 0.5f, LayerMask.GetMask("Platform"));
        bool isTouchingWallLeft = Physics2D.Raycast(rigid.position, Vector2.left, 0.5f, LayerMask.GetMask("Platform"));

        // �� �ٱ�
        if ((Input.GetKey(KeyCode.S) && (isTouchingWallLeft || isTouchingWallRight)))
        {
            rigid.velocity = Vector2.zero;
            rigid.gravityScale = 0;
            anim.SetBool("isWallCling", true);
        }
        else
        {
            rigid.gravityScale = 1;
            anim.SetBool("isWallCling", false);
        }

        // �� ����
        if (anim.GetBool("isWallCling") && Input.GetKeyDown(KeyCode.W))
        {
            int direction = isTouchingWallRight ? -1 : 1;
            rigid.AddForce(new Vector2(direction, 1) * jumpPower, ForceMode2D.Impulse);
            anim.SetBool("isJumping", true);
            rigid.gravityScale = 1;
        }

        // ����
        if (transform.position.y < -3 && !playerFall)
        {
            playerFall = true;
            audioSource.PlayOneShot(DieClip);
            Invoke("loadScene", 2f);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Train") SceneManager.LoadScene("Game222");
        if (collision.gameObject.tag == "End") SceneManager.LoadScene("End");
        if (collision.gameObject.tag == "Enemy") playerDie = true;
        if (playerDie) audioSource.PlayOneShot(DieClip);
        if (collision.gameObject.tag == "BouncePlatform") // �浹�� ��ü �±� "BouncePlatform"�� ��
        {
            rigid.velocity = new Vector2(rigid.velocity.x, 0f); // y�ӵ� �ʱ�ȭ
            rigid.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
            audioSource.PlayOneShot(jumpClip);
        }
        if (collision.CompareTag("Interactable")) // ��ȣ�ۿ� ��� �±�
        {
            canInteract = true;
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Interactable"))
        {
            canInteract = false;
            isInteracting = false; // ���� ����� ��ȣ�ۿ� ����
        }
    }

    void loadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}